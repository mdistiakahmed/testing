#!/bin/bash

# Copy Crawlee project to EC2 Script
# Usage: ./copy-to-ec2.sh

# Configuration
EC2_HOST="ec2-3-81-52-228.compute-1.amazonaws.com" # ⬅️ Replace with your EC2 public DNS or IP
USERNAME="ec2-user"                                      # ⬅️ Replace if using a different AMI user
PEM_FILE="aws-ssh-pem-key.pem"                               # ⬅️ Replace with your PEM key file name

# Check PEM file exists
if [ ! -f "$PEM_FILE" ]; then
    echo "❌ PEM file not found: $PEM_FILE"
    exit 1
fi

chmod 600 "$PEM_FILE"

echo "📦 Creating tarball without node_modules..."
tar --exclude='./node_modules' -czf project.tar.gz .

echo "🚀 Copying tarball to EC2..."
scp -i "$PEM_FILE" project.tar.gz "$USERNAME@$EC2_HOST:/tmp/"

echo "📂 Extracting on EC2..."
ssh -i "$PEM_FILE" "$USERNAME@$EC2_HOST" "mkdir -p $REMOTE_DIR && tar -xzf /tmp/project.tar.gz -C $REMOTE_DIR && rm /tmp/project.tar.gz"

rm project.tar.gz
echo "✅ Copy complete!"
echo ""
echo "💡 Connect with:"
echo "   ssh -i $PEM_FILE $USERNAME@$EC2_HOST"
echo "   cd crawlee-project"